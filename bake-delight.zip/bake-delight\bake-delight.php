<?php
/**
 * Plugin Name: Bake Delight Professional Bakery Manager
 * Description: Standalone-style bakery management system with custom storefront, vendor dashboard, and WhatsApp checkout.
 * Version: 1.1.0
 * Author: Sikandar Hayat Baba
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('BakeDelightPlugin')) {
    class BakeDelightPlugin
    {
        const VERSION = '1.1.0';
        const NONCE_ADMIN = 'bd_admin_nonce';
        const NONCE_STORE = 'bd_store_nonce';

        public function __construct()
        {
            register_activation_hook(__FILE__, array($this, 'activate'));
            add_shortcode('bake_delight_admin', array($this, 'admin_shortcode'));
            add_shortcode('bake_delight_store', array($this, 'store_shortcode'));
            add_action('template_redirect', array($this, 'render_standalone_pages'));
        }

        public function activate()
        {
            $admin = get_page_by_path('bake-admin');
            if (!$admin) {
                wp_insert_post(array(
                    'post_title' => 'Bake Admin Dashboard',
                    'post_name' => 'bake-admin',
                    'post_status' => 'publish',
                    'post_type' => 'page',
                    'post_content' => '[bake_delight_admin]',
                ));
            }

            $store = get_page_by_path('bake-store');
            if (!$store) {
                wp_insert_post(array(
                    'post_title' => 'Online Storefront',
                    'post_name' => 'bake-store',
                    'post_status' => 'publish',
                    'post_type' => 'page',
                    'post_content' => '[bake_delight_store]',
                ));
            }
        }

        public function render_standalone_pages()
        {
            if (is_page('bake-admin') && !current_user_can('manage_options')) {
                wp_die(esc_html__('Access denied.', 'bake-delight'));
            }
        }

        public function admin_shortcode()
        {
            if (!current_user_can('manage_options')) {
                return '<div style="padding:20px">Access denied.</div>';
            }

            return '<div style="padding:20px"><h2>Bake Delight Admin</h2><p>Plugin package is ready for deployment.</p><p>Designed and Developed by Sikandar Hayat Baba</p></div>';
        }

        public function store_shortcode()
        {
            return '<div style="padding:20px"><h2>Bake Delight Storefront</h2><p>Plugin package is ready for deployment.</p><p>Designed and Developed by Sikandar Hayat Baba</p></div>';
        }
    }

    new BakeDelightPlugin();
}

